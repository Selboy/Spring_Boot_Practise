package com.restApi.restservice;

public record Greeting(long id, String content) {
}
